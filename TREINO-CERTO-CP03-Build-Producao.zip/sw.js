/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "42f70f3e821d22afd3af407942161f6d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b53c6ff179799b3e2271b6b6e006cc5f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "6f8a65df692d57f75182f3f633ddfa4e"
  }, {
    "url": "index.html",
    "revision": "3af1f5bfa8beafba8374a8b2092b8480"
  }, {
    "url": "icon.svg",
    "revision": "4a8be49b250c9c783ede8a371229932f"
  }, {
    "url": "favicon.ico",
    "revision": "9795d1f94dcb9e643d148518d085f49d"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2b331a5a87a47ae7a25dccc884fac4e8"
  }, {
    "url": "images/exercises/ex_peito_supino_reto_barra.webp",
    "revision": "1465456a65c3e3ee99c2902060bd3589"
  }, {
    "url": "images/exercises/ex_peito_supino_inclinado_halteres.webp",
    "revision": "3afe7c83de69f5575a9cdf5a78da2d06"
  }, {
    "url": "images/exercises/ex_peito_crucifixo_peck_deck.webp",
    "revision": "b30be92218fe36ef6ee651fa4eaef0b2"
  }, {
    "url": "images/exercises/ex_peito_crossover_polia_alta.webp",
    "revision": "56048a85c0b99fcaf48d3fced50ae38d"
  }, {
    "url": "images/exercises/ex_costas_remada_unilateral_halter.webp",
    "revision": "651bd5e682f3cd43f5ea1e19aa9eeff4"
  }, {
    "url": "images/exercises/ex_costas_remada_curvada_barra.webp",
    "revision": "ec7f86e209caaf2e41db47c31a0ce52a"
  }, {
    "url": "images/exercises/ex_costas_remada_banco_inclinado.webp",
    "revision": "a0e34cb9ac86f707b10ee58d0508366b"
  }, {
    "url": "images/exercises/ex_costas_remada_baixa_triangulo.webp",
    "revision": "bb7cc01d80ba9ef213bc0a1016625866"
  }, {
    "url": "images/exercises/ex_costas_remada_articulada_maquina.webp",
    "revision": "c64566cd77079a10723a5b8c660b9a84"
  }, {
    "url": "images/exercises/ex_costas_puxada_alta_frontal.webp",
    "revision": "e6e0f6ec13f7ee16e23734eb7d07bc1b"
  }, {
    "url": "images/exercises/ex_costas_pullover_polia.webp",
    "revision": "0cf53afd318221d0385b76b1191a9d34"
  }, {
    "url": "images/exercises/ex_costas_barra_fixa_graviton.webp",
    "revision": "4626f695fc2108f9c7a874f6ada58051"
  }, {
    "url": "assets/index-DY7xcLl0.css",
    "revision": null
  }, {
    "url": "assets/index-DXpneXdu.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2b331a5a87a47ae7a25dccc884fac4e8"
  }, {
    "url": "favicon.ico",
    "revision": "9795d1f94dcb9e643d148518d085f49d"
  }, {
    "url": "icon.svg",
    "revision": "4a8be49b250c9c783ede8a371229932f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "6f8a65df692d57f75182f3f633ddfa4e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b53c6ff179799b3e2271b6b6e006cc5f"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "42f70f3e821d22afd3af407942161f6d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e3b1e1695ed1f5ff78e27e3d58f07ec9"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
