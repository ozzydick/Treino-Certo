/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "42f70f3e821d22afd3af407942161f6d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b53c6ff179799b3e2271b6b6e006cc5f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "6f8a65df692d57f75182f3f633ddfa4e"
  }, {
    "url": "index.html",
    "revision": "940b4601d2f6ca500e8f0b72e361264a"
  }, {
    "url": "icon.svg",
    "revision": "4a8be49b250c9c783ede8a371229932f"
  }, {
    "url": "favicon.ico",
    "revision": "9795d1f94dcb9e643d148518d085f49d"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2b331a5a87a47ae7a25dccc884fac4e8"
  }, {
    "url": "images/exercises/ex_triceps_testa_barra_w.webp",
    "revision": "62f60f16fe08fc43f6c648b127211c33"
  }, {
    "url": "images/exercises/ex_triceps_pulley_barra.webp",
    "revision": "acfd832fbbb36ad70ba62ee147296054"
  }, {
    "url": "images/exercises/ex_triceps_maquina_sentado.webp",
    "revision": "770a401e43abf90847e92c9eed5d18ac"
  }, {
    "url": "images/exercises/ex_quadriceps_leg_press_45.webp",
    "revision": "eaa9739eb9a5ca2f6de66eadd2c78519"
  }, {
    "url": "images/exercises/ex_quadriceps_hack_squat.webp",
    "revision": "ea8f4dda0682135d1b2f791215e45307"
  }, {
    "url": "images/exercises/ex_quadriceps_cadeira_extensora.webp",
    "revision": "837a99cbc59fa57683d35fa559455dc5"
  }, {
    "url": "images/exercises/ex_quadriceps_agachamento_livre.webp",
    "revision": "9f57ec6a408bd37c9388df94a1b6afd4"
  }, {
    "url": "images/exercises/ex_posterior_terra_romeno_unilateral_halter.webp",
    "revision": "9dc70f57925010edf39b3701619ed7c8"
  }, {
    "url": "images/exercises/ex_posterior_stiff_barra.webp",
    "revision": "5e66d64a01d8d0bc995cbd8a21a90198"
  }, {
    "url": "images/exercises/ex_posterior_mesa_flexora.webp",
    "revision": "097d7ebe302a2b934d330d3b093990a4"
  }, {
    "url": "images/exercises/ex_posterior_cadeira_flexora_unilateral.webp",
    "revision": "d3e9ad66e311b33ea09bb714c8a1318d"
  }, {
    "url": "images/exercises/ex_posterior_cadeira_flexora.webp",
    "revision": "c7bb4bd600f0339b2873001f68d998c5"
  }, {
    "url": "images/exercises/ex_peito_supino_reto_halteres.webp",
    "revision": "2900d63409e3be72e417a21c203b95da"
  }, {
    "url": "images/exercises/ex_peito_supino_reto_barra.webp",
    "revision": "1465456a65c3e3ee99c2902060bd3589"
  }, {
    "url": "images/exercises/ex_peito_supino_inclinado_halteres.webp",
    "revision": "3afe7c83de69f5575a9cdf5a78da2d06"
  }, {
    "url": "images/exercises/ex_peito_supino_inclinado_barra.webp",
    "revision": "f6c9d01f44a4f8212bf524df0a4936a4"
  }, {
    "url": "images/exercises/ex_peito_flexao_bracos.webp",
    "revision": "d72d367684ab3a9d99b89e9a612b3f07"
  }, {
    "url": "images/exercises/ex_peito_crucifixo_reto_halteres.webp",
    "revision": "6d3f0b6f8d3280ecb96b5e933d35a118"
  }, {
    "url": "images/exercises/ex_peito_crucifixo_peck_deck.webp",
    "revision": "b30be92218fe36ef6ee651fa4eaef0b2"
  }, {
    "url": "images/exercises/ex_peito_crossover_polia_alta.webp",
    "revision": "56048a85c0b99fcaf48d3fced50ae38d"
  }, {
    "url": "images/exercises/ex_panturrilhas_unilateral_em_pe_maquina.webp",
    "revision": "db527aef0d47713cc118b04f4f27fc2e"
  }, {
    "url": "images/exercises/ex_panturrilhas_sentado_maquina.webp",
    "revision": "70fc48220cc9a1adc687e2f9a1abf117"
  }, {
    "url": "images/exercises/ex_panturrilhas_leg_press.webp",
    "revision": "af1490449d94db2109c584bd70a1e7b3"
  }, {
    "url": "images/exercises/ex_panturrilhas_em_pe_maquina.webp",
    "revision": "0dbe67cd017243256ea0ffa5f79eea0f"
  }, {
    "url": "images/exercises/ex_ombros_elevacao_lateral_maquina.webp",
    "revision": "41567fd19e034967e16652e577e9adc7"
  }, {
    "url": "images/exercises/ex_ombros_elevacao_lateral_halteres.webp",
    "revision": "fe2a4eb7436d5682a2615c7f44d1d778"
  }, {
    "url": "images/exercises/ex_ombros_desenvolvimento_maquina.webp",
    "revision": "31e6052acf17fa2d656b514b4aae8257"
  }, {
    "url": "images/exercises/ex_ombros_desenvolvimento_halteres.webp",
    "revision": "eb31599002e4cbc8ef8de1724c0aa67c"
  }, {
    "url": "images/exercises/ex_gluteos_extensao_quadril_maquina.webp",
    "revision": "1be643b9842925ee19805213f46a35be"
  }, {
    "url": "images/exercises/ex_gluteos_elevacao_pelvica_maquina.webp",
    "revision": "c153b2004058a1ee9015d7ba57ea9d70"
  }, {
    "url": "images/exercises/ex_gluteos_cadeira_abdutora.webp",
    "revision": "4dba9172621446bf1c7596481f6ee12b"
  }, {
    "url": "images/exercises/ex_costas_remada_unilateral_halter.webp",
    "revision": "651bd5e682f3cd43f5ea1e19aa9eeff4"
  }, {
    "url": "images/exercises/ex_costas_remada_curvada_barra.webp",
    "revision": "ec7f86e209caaf2e41db47c31a0ce52a"
  }, {
    "url": "images/exercises/ex_costas_remada_banco_inclinado.webp",
    "revision": "a0e34cb9ac86f707b10ee58d0508366b"
  }, {
    "url": "images/exercises/ex_costas_remada_baixa_triangulo.webp",
    "revision": "bb7cc01d80ba9ef213bc0a1016625866"
  }, {
    "url": "images/exercises/ex_costas_remada_articulada_maquina.webp",
    "revision": "c64566cd77079a10723a5b8c660b9a84"
  }, {
    "url": "images/exercises/ex_costas_puxada_alta_frontal.webp",
    "revision": "e6e0f6ec13f7ee16e23734eb7d07bc1b"
  }, {
    "url": "images/exercises/ex_costas_pullover_polia.webp",
    "revision": "0cf53afd318221d0385b76b1191a9d34"
  }, {
    "url": "images/exercises/ex_costas_barra_fixa_graviton.webp",
    "revision": "4626f695fc2108f9c7a874f6ada58051"
  }, {
    "url": "images/exercises/ex_corpo_inteiro_kettlebell_swing.webp",
    "revision": "98fbd7ba3b1037ee4df66806c7c71339"
  }, {
    "url": "images/exercises/ex_corpo_inteiro_flexao_bracos_solo.webp",
    "revision": "d2acf8590dc19ec0f9dbb0ad3cdf75c5"
  }, {
    "url": "images/exercises/ex_corpo_inteiro_agachamento_desenvolvimento_halteres.webp",
    "revision": "0e27030286ecaaaaf6d94c265d83481c"
  }, {
    "url": "images/exercises/ex_biceps_rosca_scott.webp",
    "revision": "3588aedbaabf289a28f1145746bc7938"
  }, {
    "url": "images/exercises/ex_biceps_rosca_direta_barra.webp",
    "revision": "7acc2e92647760d53e059ac99e9a7ff8"
  }, {
    "url": "images/exercises/ex_biceps_rosca_alternada_halteres.webp",
    "revision": "e3aec40227b558af628a62715cff8b31"
  }, {
    "url": "images/exercises/ex_abdomen_supra_solo.webp",
    "revision": "e166e3932bdd9d7a826b11727cdf0408"
  }, {
    "url": "images/exercises/ex_abdomen_prancha_isometrica.webp",
    "revision": "3afb75363db476436421f6c5b9a50249"
  }, {
    "url": "images/exercises/ex_abdomen_infra_barra_fixa.webp",
    "revision": "5f0a98aa83c49a3837326d35f61f2456"
  }, {
    "url": "assets/index-DnKpn7Jf.js",
    "revision": null
  }, {
    "url": "assets/index-Cxs5D626.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "2b331a5a87a47ae7a25dccc884fac4e8"
  }, {
    "url": "favicon.ico",
    "revision": "9795d1f94dcb9e643d148518d085f49d"
  }, {
    "url": "icon.svg",
    "revision": "4a8be49b250c9c783ede8a371229932f"
  }, {
    "url": "pwa-192x192.png",
    "revision": "6f8a65df692d57f75182f3f633ddfa4e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "b53c6ff179799b3e2271b6b6e006cc5f"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "42f70f3e821d22afd3af407942161f6d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "e3b1e1695ed1f5ff78e27e3d58f07ec9"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
